# Findings Report - DevSecOps Pipeline

## 1. Run overview

| Run | Workload | Branch | Commit | Tools | Findings | Gate |
|---|---|---|---|---|---|---|
| 20261021-080950-02-cli-deps-fixed | 02-cli-deps-fixed | unknown | unknown | 0 | 0 | PASS |

## 2. Findings per severity and test class

### 20261021-080950-02-cli-deps-fixed - 02-cli-deps-fixed

| Test class | CRITICAL | HIGH | MEDIUM | LOW | INFO |
|---|---|---|---|---|---|
| **total** | 0 | 0 | 0 | 0 | 0 |

## 3. Findings detail (blocking and high severity)

### 20261021-080950-02-cli-deps-fixed

_No critical or high findings._

## 4. Stage duration (fail-fast evidence)

### 20261021-080950-02-cli-deps-fixed

| Stage | Duration (s) |
|---|---|
| secrets | 0 |
| sast | 0 |
| sca | 0 |
| build | 0 |
| image-scan | 0 |
| deploy-test | 0 |
| dast | 0 |

## 5. False positive assessment

Fill in during triage. A finding counts as a false positive only after
manual verification; the rate per tool is a core insight for the presentation.

| Tool | Findings | Verified true | False positive | FP rate |
|---|---|---|---|---|

## 6. Lessons learned

- Which tool produced the most actionable findings?
- Where did the gate block, and was the threshold appropriate?
- Which findings only the dynamic scan could reveal?
- What is still uncovered (container runtime security, IAST, pen testing)?
